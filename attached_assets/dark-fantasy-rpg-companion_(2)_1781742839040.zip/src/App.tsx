import { useState, useMemo, useCallback } from 'react';
import { TabId } from './types';
import { useGameStore } from './store';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import PlayersPanel from './components/PlayersPanel';
import PhasesPanel from './components/PhasesPanel';
import BossesPanel from './components/BossesPanel';
import RewardsPanel from './components/RewardsPanel';
import LogPanel from './components/LogPanel';
import { RotateCcw } from 'lucide-react';

// Gerar partículas uma vez só (fora do render)
interface Particle {
  id: number;
  width: number;
  height: number;
  color: string;
  left: number;
  top: number;
  duration: number;
  delay: number;
}

function generateParticles(count: number): Particle[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    width: Math.random() * 4 + 1,
    height: Math.random() * 4 + 1,
    color: i % 3 === 0 ? '#ef4444' : i % 3 === 1 ? '#f59e0b' : '#8b5cf6',
    left: Math.random() * 100,
    top: Math.random() * 100,
    duration: 3 + Math.random() * 4,
    delay: Math.random() * 3,
  }));
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [showReset, setShowReset] = useState(false);
  const store = useGameStore();

  // Memorizar partículas para não recalcular a cada render
  const particles = useMemo(() => generateParticles(12), []);

  const handleTabChange = useCallback((tab: TabId) => {
    console.log(`[Navigation] Mudando para aba: ${tab}`);
    setActiveTab(tab);
  }, []);

  const renderContent = () => {
    console.log(`[Render] Renderizando aba: ${activeTab}`);
    
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard players={store.players} logs={store.logs} onNavigate={handleTabChange} />;
      case 'players':
        return (
          <PlayersPanel
            players={store.players}
            addPlayer={store.addPlayer}
            removePlayer={store.removePlayer}
            adjustHealth={store.adjustHealth}
            addXP={store.addXP}
            setLevel={store.setLevel}
          />
        );
      case 'phases':
        return <PhasesPanel players={store.players} addLog={store.addLog} />;
      case 'bosses':
        return (
          <BossesPanel
            players={store.players}
            addLog={store.addLog}
            adjustHealth={store.adjustHealth}
            bossHealths={store.bossHealths}
            adjustBossHealth={store.adjustBossHealth}
            resetBossHealth={store.resetBossHealth}
          />
        );
      case 'rewards':
        return (
          <RewardsPanel
            players={store.players}
            addItemToPlayer={store.addItemToPlayer}
            removeItemFromPlayer={store.removeItemFromPlayer}
          />
        );
      case 'log':
        return <LogPanel logs={store.logs} clearLogs={store.clearLogs} />;
      default:
        console.warn(`[Render] Aba desconhecida: ${activeTab}`);
        return (
          <div className="card-dark rounded-xl p-8 text-center">
            <div className="text-3xl mb-3">❓</div>
            <p className="text-gray-400">Aba não encontrada</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-dark-gradient relative">
      {/* Background Image - z-index 0, pointer-events none */}
      <div
        className="fixed inset-0 z-0 bg-cover bg-center opacity-[0.07] pointer-events-none"
        style={{ backgroundImage: "url('/images/bg-castle.jpg')" }}
      />

      {/* Ambient Particles Effect - z-index 1, pointer-events none */}
      <div className="fixed inset-0 z-[1] pointer-events-none overflow-hidden">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute rounded-full opacity-20"
            style={{
              width: `${particle.width}px`,
              height: `${particle.height}px`,
              background: particle.color,
              left: `${particle.left}%`,
              top: `${particle.top}%`,
              animation: `float ${particle.duration}s ease-in-out ${particle.delay}s infinite`,
            }}
          />
        ))}
      </div>

      {/* Navigation - z-index 40 */}
      <Navigation
        activeTab={activeTab}
        onTabChange={handleTabChange}
        playerCount={store.players.length}
      />

      {/* Main Content - z-index 10, ACIMA dos backgrounds */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 py-4 pb-20">
        {renderContent()}
      </main>

      {/* Footer - z-index 30 */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 border-t border-red-900/10"
        style={{ background: 'rgba(10,10,15,0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="max-w-4xl mx-auto px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] text-gray-600">
            <span className="text-red-400">💎</span>
            <span>O Reino do Rei Sombrio</span>
            <span>•</span>
            <span>RPG Companion</span>
          </div>
          <button
            onClick={() => {
              console.log('[Footer] Abrindo modal de reset');
              setShowReset(true);
            }}
            className="text-gray-600 hover:text-red-400 p-1 transition-colors"
            title="Resetar tudo"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </footer>

      {/* Reset Confirmation Modal - z-index 50 */}
      {showReset && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay" 
          onClick={() => setShowReset(false)}
        >
          <div 
            className="max-w-sm w-full card-dark rounded-xl p-6 animate-fadeIn" 
            onClick={e => e.stopPropagation()}
          >
            <div className="text-center space-y-4">
              <div className="text-3xl">⚠️</div>
              <h3 className="text-lg font-bold text-red-400" style={{ fontFamily: 'Cinzel, serif' }}>
                Resetar Tudo?
              </h3>
              <p className="text-sm text-gray-400">
                Todos os jogadores, inventários, vida dos bosses e registros serão apagados permanentemente.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowReset(false)}
                  className="flex-1 btn-dark px-4 py-2.5 rounded-lg text-sm font-medium"
                >
                  Cancelar
                </button>
                <button 
                  onClick={() => { 
                    store.resetAll(); 
                    setShowReset(false); 
                    setActiveTab('dashboard'); 
                  }}
                  className="flex-1 bg-red-900/50 hover:bg-red-900 text-red-300 px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors border border-red-800/50"
                >
                  Resetar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
