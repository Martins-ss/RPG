import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import ErrorBoundary from "./components/ErrorBoundary";

// Log de inicialização
console.log('[App] Iniciando O Reino do Rei Sombrio - RPG Companion');
console.log('[App] Versão: 1.0.0');

const rootElement = document.getElementById("root");

if (!rootElement) {
  console.error('[App] Elemento root não encontrado!');
  document.body.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #0a0a0f; color: #ef4444; font-family: sans-serif; text-align: center; padding: 20px;">
      <div>
        <h1>Erro Crítico</h1>
        <p>Elemento root não encontrado. Recarregue a página.</p>
      </div>
    </div>
  `;
} else {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
}
